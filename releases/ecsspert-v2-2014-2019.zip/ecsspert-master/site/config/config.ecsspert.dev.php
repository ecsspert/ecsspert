<?php

// flag for dev environment
c::set('devenv',true);

?>
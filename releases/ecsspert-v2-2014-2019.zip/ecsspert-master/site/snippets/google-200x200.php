<script type="text/javascript"><!--
    google_ad_client = "ca-pub-2731516173086685";
    /* eCSSpert homelist */
    google_ad_slot = "8886970593";
    google_ad_width = 200;
    google_ad_height = 200;
    //-->
    </script>
    <script type="text/javascript"
    src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

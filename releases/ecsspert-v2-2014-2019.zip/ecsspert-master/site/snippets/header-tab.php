<header class="fbox">
    <a id="logo" class="ecsspert fleft" href="#home">eCSSpert</a>
    <a class="beta fleft" href="#home">beta</a>
    <a class="menu fright" href="/misc/about">About</a>
</header>
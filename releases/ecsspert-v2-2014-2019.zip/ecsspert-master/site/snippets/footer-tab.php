<footer>
    <a class="contact mail fleft" href="mailto:hello@ecsspert.com" target="_blank">Mail</a>
    <a class="contact twitter fleft" href="http://twitter.com/ecsspert" target="_blank">Twitter</a>
    <a class="contact dribbble fleft" href="http://dribbble.com/ecsspert" target="_blank">Dribbble</a>
</footer>